package BuilderPattern;

public interface Packing {
    public String pack();
    public int price();
}
